import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = 'http://10.77.30.154:5000/api';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add interceptor to include JWT token
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('userToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Standardize error structures
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (!error.response) {
      // Network Error
      const networkError = {
        success: false,
        code: 'NETWORK_ERROR',
        message: 'Network connection failed. Please check your connection and try again.'
      };
      return Promise.reject(networkError);
    }
    const backendError = error.response.data || {
      success: false,
      code: 'SERVER_ERROR',
      message: error.message || 'An internal server error occurred.'
    };
    return Promise.reject(backendError);
  }
);

export const authService = {
  login: async (email: string, password: string) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      if (response.data.token) {
        await AsyncStorage.setItem('userToken', response.data.token);
        await AsyncStorage.setItem('userData', JSON.stringify(response.data.user));
      }
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  register: async (name: string, email: string, password: string) => {
    try {
      const response = await api.post('/auth/register', { name, email, password });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  logout: async () => {
    await AsyncStorage.removeItem('userToken');
    await AsyncStorage.removeItem('userData');
    await AsyncStorage.removeItem('rememberMe');
  },
  forgotPassword: async (email: string) => {
    try {
      const response = await api.post('/auth/forgot-password', { email });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  verifyResetOTP: async (email: string, otp: string) => {
    try {
      const response = await api.post('/auth/verify-reset-otp', { email, otp });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  resetPassword: async (email: string, otp: string, password: string) => {
    try {
      const response = await api.post('/auth/reset-password', { email, otp, password });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  sendVerification: async (email: string) => {
    try {
      const response = await api.post('/auth/send-verification', { email });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  verifyEmail: async (email: string, otp: string) => {
    try {
      const response = await api.post('/auth/verify-email', { email, otp });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  resendVerification: async (email: string) => {
    try {
      const response = await api.post('/auth/resend-verification', { email });
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  validateToken: async () => {
    try {
      const response = await api.get('/auth/validate-token');
      return response.data;
    } catch (error: any) {
      throw error;
    }
  },
  googleLogin: async (email: string, name: string) => {
    try {
      const response = await api.post('/auth/google-login', { email, name });
      if (response.data.token) {
        await AsyncStorage.setItem('userToken', response.data.token);
        await AsyncStorage.setItem('userData', JSON.stringify(response.data.user));
      }
      return response.data;
    } catch (error: any) {
      throw error;
    }
  }
};

export const marketService = {
  getPriceLKR: async (symbol: string = 'BTCUSDT') => {
    try {
      const response = await api.get(`/market/price-lkr`, {
        params: { symbol },
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching LKR price:', error);
      throw error;
    }
  },
  getMultiplePricesLKR: async (symbols: string[] = ['BTCUSDT', 'ETHUSDT'], includeSparkline: boolean = false) => {
    try {
      const response = await api.get(`/market/prices-lkr`, {
        params: { 
          symbols: symbols.join(','),
          sparkline: includeSparkline 
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching multiple LKR prices:', error);
      throw error;
    }
  },
  getAllPricesLKR: async () => {
    try {
      const response = await api.get(`/market/all-prices-lkr`);
      return response.data;
    } catch (error) {
      console.error('Error fetching all LKR prices:', error);
      throw error;
    }
  },
  getLivePrices: async () => {
    try {
      const response = await api.get('/market/live');
      return response.data;
    } catch (error) {
      console.error('Error fetching live market prices:', error);
      throw error;
    }
  },
};

export const walletService = {
  getBalance: async () => {
    try {
      const response = await api.get('/wallet/balance');
      return response.data;
    } catch (error) {
      console.error('Error fetching wallet balance:', error);
      throw error;
    }
  },
  deposit: async (amount: number) => {
    try {
      const response = await api.post('/wallet/deposit', { amount });
      return response.data;
    } catch (error) {
      console.error('Error depositing money:', error);
      throw error;
    }
  },
  getTransactions: async () => {
    try {
      const response = await api.get('/wallet/transactions');
      return response.data;
    } catch (error) {
      console.error('Error fetching transactions:', error);
      throw error;
    }
  },
  getWalletDetails: async () => {
    try {
      const response = await api.get('/wallet');
      return response.data;
    } catch (error) {
      console.error('Error fetching wallet details:', error);
      throw error;
    }
  },
};

export const alertService = {
  createAlert: async (symbol: string, targetPrice: number, alertType: 'ABOVE' | 'BELOW') => {
    try {
      const response = await api.post('/alerts', { symbol, targetPrice, alertType });
      return response.data;
    } catch (error: any) {
      console.error('Error creating alert:', error.response?.data || error.message);
      throw error.response?.data || error;
    }
  },
  getUserAlerts: async () => {
    try {
      const response = await api.get('/alerts');
      return response.data;
    } catch (error) {
      console.error('Error fetching alerts:', error);
      throw error;
    }
  },
  deleteAlert: async (id: number) => {
    try {
      const response = await api.delete(`/alerts/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting alert:', error);
      throw error;
    }
  },
  savePushToken: async (token: string) => {
    try {
      const response = await api.post('/alerts/push-token', { token });
      return response.data;
    } catch (error) {
      console.error('Error saving push token:', error);
      throw error;
    }
  },
};

export const tradeService = {
  buy: async (symbol: string, amountLKR: number) => {
    try {
      const response = await api.post('/trade/buy', { symbol, amountLKR });
      return response.data;
    } catch (error) {
      console.error('Error executing buy trade:', error);
      throw error;
    }
  },
  sell: async (symbol: string, quantity: number) => {
    try {
      const response = await api.post('/trade/sell', { symbol, quantity });
      return response.data;
    } catch (error) {
      console.error('Error executing sell trade:', error);
      throw error;
    }
  }
};

export const portfolioService = {
  getPortfolio: async () => {
    try {
      const response = await api.get('/portfolio');
      return response.data;
    } catch (error) {
      console.error('Error fetching portfolio:', error);
      throw error;
    }
  }
};

export const transactionService = {
  getTransactions: async () => {
    try {
      const response = await api.get('/transactions');
      return response.data;
    } catch (error) {
      console.error('Error fetching transaction history:', error);
      throw error;
    }
  }
};

export default api;
